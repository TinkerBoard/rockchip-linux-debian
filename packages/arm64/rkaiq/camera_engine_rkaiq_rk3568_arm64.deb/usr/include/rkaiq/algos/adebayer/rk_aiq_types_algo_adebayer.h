#ifndef __RKAIQ_TYPES_ALGO_ADEBAYER_H__
#define __RKAIQ_TYPES_ALGO_ADEBAYER_H__

#include "rk_aiq_comm.h"


#endif//__RKAIQ_TYPES_ALGO_ADEBAYER_H__
