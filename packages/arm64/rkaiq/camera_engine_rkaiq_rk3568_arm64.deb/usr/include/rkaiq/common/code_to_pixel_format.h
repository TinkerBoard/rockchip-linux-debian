#ifndef _CODE_TO_PIXEL_FORMAT_H
#define _CODE_TO_PIXEL_FORMAT_H
#include "rk_aiq_comm.h"

RKAIQ_BEGIN_DECLARE

extern uint32_t get_v4l2_pixelformat(uint32_t pixelcode);

RKAIQ_END_DECLARE

#endif