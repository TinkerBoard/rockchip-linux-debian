/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
/* Copyright (c) 2018 Fuzhou Rockchip Electronics Co., Ltd. */
#ifndef RK_LED_FLASH_H
#define RK_LED_FLASH_H

#define RK_VIDIOC_FLASH_TIMEINFO \
	_IOR('V', BASE_VIDIOC_PRIVATE + 0, struct timeval)

#endif
